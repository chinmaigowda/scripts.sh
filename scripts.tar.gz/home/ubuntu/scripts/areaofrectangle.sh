Hi
Hello
How
Who
When
