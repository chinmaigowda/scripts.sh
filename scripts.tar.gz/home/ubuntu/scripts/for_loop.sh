#!/bin/bash

echo "C-Styled for loop"
for (( i=1; i<=10; i++ ))
do
   echo "$i"
done

#for i in {1..10}; do
#   echo "$i"
#done
