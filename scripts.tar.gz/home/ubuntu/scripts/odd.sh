#!/bin/bash
file=$1
while read line; do
((count++))

