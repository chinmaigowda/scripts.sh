
count=1
echo "$count: $line"
done < "$file"
